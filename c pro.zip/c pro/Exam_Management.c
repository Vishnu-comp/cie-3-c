#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>

//Vishnu's Code
#define MAX_COURSES 5
#define MAX_STRING_LENGTH 50

typedef struct {
    char code[MAX_STRING_LENGTH];
    char name[MAX_STRING_LENGTH];
    int credits;
} Course;

typedef struct {
    char name[MAX_STRING_LENGTH];
    char domain[MAX_STRING_LENGTH];
    char password[MAX_STRING_LENGTH];
} Teacher;

typedef struct {
    long int regNumber;
    char name[MAX_STRING_LENGTH];
    float sub1_marks;
    float sub2_marks;
    float sub3_marks;
    float sub4_marks;
    float sub5_marks;
    char password[MAX_STRING_LENGTH];
} Student;

// Function prototypes
void addCourse(Course courses[], int *numCourses);
void displayCourses(Course courses[], int numCourses);
void updateCourse(Course courses[], int numCourses);
void deleteCourse(Course courses[], int *numCourses);
void saveCoursesToFile(Course courses[], int numCourses, const char *filename);
void loadCoursesFromFile(Course courses[], int *numCourses, const char *filename);
void createCourseFolder(const char *folderName);

void addTeacher(const char *courseCode);
void addStudent(const char *courseCode);
int authenticateTeacher(const char *teacherName, const char *courseCode, const char *password);
int authenticateStudent(long int studentID, const char *courseName, const char *password);


//Michelle's
void addqp();
void deleteQuestionPaper();
void updateQuestionPaper();
void viewQuestionPaper();

void updateStudentMarks();
void viewStudentDetails();

int main() {
    char username[MAX_STRING_LENGTH];
    char password[MAX_STRING_LENGTH];
    char coursename[MAX_STRING_LENGTH];
    long int regNum;
    int choice;
    
    //Admin
    Course courses[MAX_COURSES];
	int numCourses = 0;

    while (1) {
        printf("Welcome to the login system\n");
        printf("1. Admin Login\n");
        printf("2. Teacher Login\n");
        printf("3. Student Login\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Admin Login\n");
                printf("Enter username: ");
                scanf("%s", username);
                printf("Enter password: ");
                scanf("%s", password);

                // Check admin credentials here
                if (strcmp(username, "admin") == 0 && strcmp(password, "admin123") == 0) {
                    printf("Admin login successful!\n");

				    char admin_choice;
				
				    // Load courses from a file (if available)
				    loadCoursesFromFile(courses, &numCourses, "courses.csv");
				
				    while (1) {
				        printf("\nCourse Management System\n");
				        printf("1. Add Course\n");
				        printf("2. Display Courses\n");
				        printf("3. Update Course\n");
				        printf("4. Delete Course\n");
				        printf("5. Exit\n");
				        printf("Enter your choice: ");
				        scanf(" %c", &admin_choice);
				
				        switch (admin_choice) {
				            case '1':
				                addCourse(courses, &numCourses);
				                saveCoursesToFile(courses, numCourses, "courses.csv");
				                break;
				            case '2':
				                displayCourses(courses, numCourses);
				                break;
				            case '3':
				                updateCourse(courses, numCourses);
				                saveCoursesToFile(courses, numCourses, "courses.csv");
				                break;
				            case '4':
				                deleteCourse(courses, &numCourses);
				                saveCoursesToFile(courses, numCourses, "courses.csv");
				                break;
				            case '5':
				                printf("Goodbye!\n");
				                exit(0);
				            default:
				                printf("Invalid choice. Please try again.\n");
				        }
				    }
                } else {
                    printf("Admin login failed. Please try again.\n");
                }
                break;

            case 2:
            	
                printf("Teacher Login\n");
                printf("Enter course name: ");
                scanf("%s", coursename);
                printf("Enter name: ");
                scanf("%s", username);
                printf("Enter password: ");
                scanf("%s", password);

                // Check teacher credentials here
                // Replace the condition with your actual validation logic
                int authenticated = authenticateTeacher(username, coursename, password);
                if (authenticated) {
                    printf("Authentication successful. You are logged in as a teacher.\n");
                    int choice;
				    char continueChoice;
				
				    do
				    {
				        printf("Select an operation:\n");
				        printf("1. Add Question Paper\n");
				        printf("2. Delete Question Paper\n");
				        printf("3. Update Question Paper\n");
				        printf("4. View Question Paper\n");
				        printf("5. Update Student Marks\n");
				        printf("6. View Student Detail\n");
				        printf("7. Exit\n");
				        scanf("%d", &choice);
				
				        // Flush any remaining newline characters in the input buffer
				        while ((getchar()) != '\n');
				
				        switch (choice)
				        {
				            case 1:
				                addqp();
				                break;
				            case 2:
				                deleteQuestionPaper();
				                break;
				            case 3:
				                updateQuestionPaper();
				                break;
				            case 4:
				                viewQuestionPaper();
				                break;
				            case 5:
				                updateStudentMarks();
				                break;
				            case 6:
				                viewStudentDetails();
				                break;
				            case 7:
				                printf("Exiting the program.\n");
				                return 0; // Exit the program
				            default:
				                printf("Invalid choice. Exiting the program.\n");
				                return 0; // Exit the program
				        }
				
				        printf("Do you want to perform another operation? (y/n): ");
				        scanf(" %c", &continueChoice);
				
				        // Flush any remaining newline characters in the input buffer
				        while ((getchar()) != '\n');
				
				    } while (continueChoice == 'y' || continueChoice == 'Y');
                    
                } else {
                    printf("Authentication failed. Please check your credentials.\n");
                }
                break;

            case 3:
                printf("Student Login\n");
                printf("Enter course name: ");
                scanf("%s", coursename);
                printf("Enter password: ");
                scanf("%s", password);
                printf("Enter Reg. No.: ");
                scanf("%ld", &regNum);
                
                int authenticated2 = authenticateStudent(regNum, coursename, password);
                if (authenticated2) {
                    printf("Authentication successful. You are logged in as a student.\n");
                    
                    int choice;
				    char continueChoice;
                    do
				    {
				        printf("Select an operation:\n");
				        printf("1. View Student Details\n");
				        printf("2. Exit\n");
				        scanf("%d", &choice);
				
				        while ((getchar()) != '\n');
				
				        switch (choice)
				        {
				            case 1:
				                viewStudentDetails();
				                break;
				            case 2:
				                printf("Exiting the program.\n");
				                return 0; // Exit the program
				            default:
				                printf("Invalid choice. Exiting the program.\n");
				                return 0; // Exit the program
				        }
				
				        printf("Do you want to perform another operation? (y/n): ");
				        scanf(" %c", &continueChoice);
				
				        while ((getchar()) != '\n');
				
				    } while (continueChoice == 'y' || continueChoice == 'Y');
                    
            	} else {
                    printf("Authentication failed. Please check your credentials.\n");
                }
                break;

            case 4:
                printf("Exiting the program.\n");
                return 0;

            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    }

    return 0;
}


void createCourseFolder(const char *folderName) {
    char path[100];
    snprintf(path, sizeof(path), "courses/%s", folderName);
    int status = mkdir(path); 
    if (status == 0) {
        printf("Created folder for course: %s\n", folderName);
        
        snprintf(path, sizeof(path), "courses/%s/question_papers", folderName);
    	int status1 = mkdir(path);
    	
    	if(status1 != 0) printf("Failed QP folder\n"); 
        
    } else {
        printf("Failed to create folder for course: %s\n", folderName);
    }
}

void addTeacher(const char *courseCode) {
    Teacher newTeacher;
    printf("Enter teacher name: ");
    scanf("%s", newTeacher.name);
    printf("Enter teacher domain: ");
    scanf("%s", newTeacher.domain);
    printf("Enter teacher password: ");
    scanf("%s", newTeacher.password);

    // Create and open the teachers.csv file
    char filename[100];
    snprintf(filename, sizeof(filename), "courses/%s/teachers.csv", courseCode);
    FILE *file = fopen(filename, "a"); // Append mode to add a new teacher
    if (file == NULL) {
        printf("Error opening teachers.csv for writing.\n");
        return;
    }

    // Write the teacher's details to the file
    fprintf(file, "%s,%s,%s\n", newTeacher.name, newTeacher.domain, newTeacher.password);
    fclose(file);
    printf("Teacher added successfully!\n");
}

void addStudent(const char *courseCode) {
    Student newStudent;
    newStudent.sub1_marks = 0; 
    newStudent.sub2_marks = 0; 
    newStudent.sub3_marks = 0; 
    newStudent.sub4_marks = 0; 
    newStudent.sub5_marks = 0; 
    printf("Enter student name: ");
    scanf("%s", newStudent.name);
    printf("Enter student Reg. No.: ");
    scanf("%ld", &newStudent.regNumber);
    printf("Enter student password: ");
    scanf("%s", newStudent.password);
    
    printf("%s, %ld, %s", newStudent.name, newStudent.regNumber, newStudent.password);
    

    // Create and open the students.csv file
    char filename[100];
    snprintf(filename, sizeof(filename), "courses/%s/students.csv", courseCode);
    FILE *file = fopen(filename, "a"); // Append mode to add a new student
    if (file == NULL) {
        printf("Error opening students.csv for writing.\n");
        return;
    }

    // Write the student's details to the file
    fprintf(file, "%d,%s,%.2f,%.2f,%.2f,%.2f,%.2f,%s\n", newStudent.regNumber, newStudent.name, newStudent.sub1_marks, newStudent.sub2_marks, newStudent.sub3_marks, newStudent.sub4_marks, newStudent.sub5_marks, newStudent.password);

    fclose(file);
    printf("Student added successfully!\n");
}


int authenticateTeacher(const char *teacherName, const char *courseName, const char *password) {
    char filename[100];
    snprintf(filename, sizeof(filename), "courses/%s/teachers.csv", courseName);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Course folder or teachers.csv not found.\n");
        return 0; // Authentication failed
    }

    char line[MAX_STRING_LENGTH * 3]; // Allow for name, domain, and password fields

    while (fgets(line, sizeof(line), file) != NULL) {
        char storedTeacherName[MAX_STRING_LENGTH];
        char storedDomain[MAX_STRING_LENGTH];
        char storedPassword[MAX_STRING_LENGTH];
        
        // Read name, domain, and password fields
        sscanf(line, "%[^,],%[^,],%[^,\n]", storedTeacherName, storedDomain, storedPassword);

        // Check if the stored teacher name and password match the provided values
        if (strcmp(storedTeacherName, teacherName) == 0) {
        	
        	size_t len = strlen(storedPassword);
            if (len > 0 && storedPassword[len - 1] == '\n') {
                storedPassword[len - 1] = '\0';
            }
            
            // Now, check if the stored password matches the provided password
            if (strcmp(storedPassword, password) == 0) {
                fclose(file);
                return 1; // Authentication successful
            } else {
                fclose(file);
                return 0; // Password does not match
            }
        }
    }

    fclose(file);
    return 0; // Authentication failed
}

int authenticateStudent(long int studentID, const char *courseName, const char *password) {
//	printf("%s, %s, %ld", courseName, password, studentID);
    char filename[100];
    snprintf(filename, sizeof(filename), "courses/%s/students.csv", courseName);

    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Course folder or students.csv not found.\n");
        return 0; // Authentication failed
    }

    char line[MAX_STRING_LENGTH * 8]; // Allow for ID, name, and password fields

    while (fgets(line, sizeof(line), file) != NULL) {
        long int storedID;
        char storedName[MAX_STRING_LENGTH];
        char storedPassword[MAX_STRING_LENGTH];
        
        // Read ID, name, and password fields
        sscanf(line, "%ld,%[^,],%*[^,],%*[^,],%*[^,],%*[^,],%*[^,],%[^,\n]", &storedID, storedName, storedPassword);
//        printf("%s, %s, %ld", storedName, storedPassword, storedID);

        // Check if the stored student ID matches the provided ID
        if (storedID == studentID) {
            size_t len = strlen(storedPassword);
            if (len > 0 && storedPassword[len - 1] == '\n') {
                storedPassword[len - 1] = '\0';
            }
            
            // Now, check if the stored password matches the provided password
            if (strcmp(storedPassword, password) == 0) {
                fclose(file);
                return 1; // Authentication successful
            } else {
                fclose(file);
                return 0; // Password does not match
            }
        }
    }

    fclose(file);
    return 0; // Authentication failed
}



//Vishnu's Code
void addCourse(Course courses[], int *numCourses) {
	int i;
    if (*numCourses < MAX_COURSES) {
        Course newCourse;
        printf("Enter course code: ");
        scanf("%s", newCourse.code);
        printf("Enter course name: ");
        scanf("%s", newCourse.name);
        printf("Enter course credits: ");
        scanf("%d", &newCourse.credits);
        
        
        for (i = 0; i < *numCourses; i++) {
            if (strcmp(newCourse.code, courses[i].code) == 0) {
                printf("Course with code %s already exists. Cannot add a duplicate course.\n", newCourse.code);
                return; // Return without adding the course
            }
            if (strcmp(newCourse.name, courses[i].name) == 0) {
                printf("Course with name %s already exists. Cannot add a duplicate course.\n", newCourse.name);
                return; // Return without adding the course
            }
        }
        
        courses[*numCourses] = newCourse;
        (*numCourses)++;
        printf("Course added successfully!\n");
        
        createCourseFolder(newCourse.name);
        
        int numTeachers, numStudents;
        printf("Enter the number of teachers to add: ");
        scanf("%d", &numTeachers);
        
        printf("Enter the number of students to add: ");
        scanf("%d", &numStudents);

        for (i = 0; i < numTeachers; i++) {
            // Prompt for teacher details and add to teachers.csv
            addTeacher(newCourse.name);
        }

        for (i = 0; i < numStudents; i++) {
            // Prompt for student details and add to students.csv
            addStudent(newCourse.name);
        }
    } else {
        printf("Maximum number of courses reached.\n");
    }
}

void displayCourses(Course courses[], int numCourses) {
	int i;
    if (numCourses > 0) {
        printf("\nCourses:\n");
        printf("Code\tName\tCredits\n");
        for (i = 0; i < numCourses; i++) {
            printf("%s\t%s\t%d\n", courses[i].code, courses[i].name, courses[i].credits);
        }
    } else {
        printf("No courses found.\n");
    }
}

void updateCourse(Course courses[], int numCourses) {
    char code[MAX_STRING_LENGTH];
    char newName[MAX_STRING_LENGTH];
    int i,j;
    printf("Enter the course code to update: ");
    scanf("%s", code);

    for (i = 0; i < numCourses; i++) {
        if (strcmp(courses[i].code, code) == 0) {
            printf("Enter new course name: ");
            scanf("%s", newName);
            
            for (j = 0; j < numCourses; j++) {
                if (i != j && strcmp(courses[j].name, newName) == 0) {
                    printf("Course with the new name already exists. Update failed.\n");
                    return;
                }
            }

            strcpy(courses[i].name, newName);
            
            printf("Enter new course credits: ");
            scanf("%d", &courses[i].credits);
            printf("Course updated successfully!\n");
            return;
        }
    }

    printf("Course not found.\n");
}

void deleteCourse(Course courses[], int *numCourses) {
    char code[MAX_STRING_LENGTH];
    int i,j;
    printf("Enter the course code to delete: ");
    scanf("%s", code);

    for (i = 0; i < *numCourses; i++) {
        if (strcmp(courses[i].code, code) == 0) {
            // Shift all courses after the deleted course one position to the left
            for (j = i; j < (*numCourses - 1); j++) {
                courses[j] = courses[j + 1];
            }
            (*numCourses)--;
            printf("Course deleted successfully!\n");
            return;
        }
    }

    printf("Course not found.\n");
}

void saveCoursesToFile(Course courses[], int numCourses, const char *filename) {
	int i;
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    for (i = 0; i < numCourses; i++) {
        fprintf(file, "%s,%s,%d\n", courses[i].code, courses[i].name, courses[i].credits);
    }

    fclose(file);
    printf("Courses saved to %s.\n", filename);
}

void loadCoursesFromFile(Course courses[], int *numCourses, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("File does not exist. Creating a new one.\n");
        return;
    }

    char line[MAX_STRING_LENGTH * 3]; // Allow for code, name, and credits
    *numCourses = 0;

    while (fgets(line, sizeof(line), file) != NULL) {
        if (*numCourses < MAX_COURSES) {
            sscanf(line, "%[^,],%[^,],%d", courses[*numCourses].code, courses[*numCourses].name, &courses[*numCourses].credits);
            (*numCourses)++;
        } else {
            printf("Maximum number of courses reached. Some courses were not loaded.\n");
            break;
        }
    }

    fclose(file);
    printf("Loaded %d courses from %s.\n", *numCourses, filename);
}


//Michelle's
char dirPath[100] = "D:\christ\c pro\courses\\%s\\question_papers\\%s";

void addqp()
{
    FILE *fptr;
    int num, i;
    char question[200]; // Increase the size to accommodate longer questions
    char optionA[50], optionB[50], optionC[50], optionD[50];
    char answer;
    char teacher[100], className[100], subject[100];
    char fileName[200]; // Increase the size to accommodate longer file paths
    char coursename[50];
    
    printf("Enter the course name: ");
    fgets(coursename, sizeof(coursename), stdin);
	coursename[strcspn(coursename, "\n")] = '\0';
    
    printf("Enter the name of the question paper file (without extension): ");
    fgets(fileName, sizeof(fileName), stdin);
	fileName[strcspn(fileName, "\n")] = '\0';

    // Append ".txt" to the provided file name
    strcat(fileName, ".txt");

    // Create the complete file path
    char filePath[200];
    snprintf(filePath, sizeof(filePath), dirPath, coursename, fileName);
    printf("%s", filePath);

    fptr = fopen(filePath, "w");

    if (fptr == NULL)
    {
        printf("Error opening the file!\n");
        exit(1);
    }

    printf("\nEnter teacher's name: ");
    fgets(teacher, sizeof(teacher), stdin);
	teacher[strcspn(teacher, "\n")] = '\0';

    printf("Enter class: ");
    fgets(className, sizeof(className), stdin);
	className[strcspn(className, "\n")] = '\0';

    printf("Enter subject: ");
    fgets(subject, sizeof(subject), stdin);
	subject[strcspn(subject, "\n")] = '\0';

    printf("Enter number of questions: ");
    scanf("%d", &num);

    while ((getchar()) != '\n');

    fprintf(fptr, "Teacher: %s\n", teacher);
    fprintf(fptr, "Class: %s\n", className);
    fprintf(fptr, "Subject: %s\n", subject);

    for (i = 0; i < num; i++)
    {
        printf("Enter MCQ question %d:\n", i + 1);
        fgets(question, sizeof(question), stdin);

        printf("Option A: ");
        fgets(optionA, sizeof(optionA), stdin);

        printf("Option B: ");
        fgets(optionB, sizeof(optionB), stdin);

        printf("Option C: ");
        fgets(optionC, sizeof(optionC), stdin);

        printf("Option D: ");
        fgets(optionD, sizeof(optionD), stdin);

        printf("Enter the correct answer (A/B/C/D): ");
        scanf(" %c", &answer);

        while ((getchar()) != '\n');

        fprintf(fptr, "Question %d: %s", i + 1, question);
        fprintf(fptr, "A: %s", optionA);
        fprintf(fptr, "B: %s", optionB);
        fprintf(fptr, "C: %s", optionC);
        fprintf(fptr, "D: %s", optionD);
        fprintf(fptr, "Answer: %c\n", answer);
    }

    fclose(fptr);
}


void deleteQuestionPaper()
{
    char fileName[100];
	char coursename[50];
    
    printf("Enter the course name: ");
    scanf("%s", coursename);

    printf("Enter the name of the question paper file to delete (without extension): ");
    scanf("%s", fileName);

    // Remove the newline character from the input
    fileName[strcspn(fileName, "\n")] = '\0';

    // Append ".txt" to the provided file name
    strcat(fileName, ".txt");

    // Create the complete file path
    char filePath[200];
    snprintf(filePath, sizeof(filePath), dirPath, coursename, fileName);

    // Attempt to delete the file
    if (remove(filePath) == 0)
    {
        printf("Question paper '%s' has been deleted successfully!\n", fileName);
    }
    else
    {
        perror("Error deleting the file");
    }
}

void updateQuestionPaper()
{
    FILE *fptr;
    int numToAdd, i, existingQuestions = 0;
    char question[100];
    char options[4][50]; // Array to store 4 options for each question
    char fileName[100];
    char answer[2]; // To store the correct answer (A, B, C, or D)
    char coursename[50];
    
    printf("Enter the course name: ");
    scanf("%s", coursename);

    printf("Enter the name of the question paper file to update (without extension): ");
    scanf("%s", fileName);

    // Remove the newline character from the input
    fileName[strcspn(fileName, "\n")] = '\0';

    // Append ".txt" to the provided file name
    strcat(fileName, ".txt");

    // Create the complete file path
    char filePath[200];
    snprintf(filePath, sizeof(filePath), dirPath, coursename, fileName);

    // Open the file for reading to determine the existing question count
    fptr = fopen(filePath, "r");

    if (fptr != NULL)
    {
        char line[100];
        while (fgets(line, sizeof(line), fptr) != NULL)
        {
            if (strncmp(line, "Question ", 9) == 0)
            {
                existingQuestions++;
            }
        }
        fclose(fptr);
    }
    else
    {
        perror("Error opening the file for reading");
        exit(1);
    }

    // Reopen the file for appending
    fptr = fopen(filePath, "a");

    if (fptr == NULL)
    {
        perror("Error opening the file");
        exit(1);
    }

    printf("Enter the number of new questions to add: ");
    scanf("%d", &numToAdd);

    while ((getchar()) != '\n');

    for (i = 0; i < numToAdd; i++)
    {
        printf("Enter new question %d: ", existingQuestions + i + 1);
        fgets(question, sizeof(question), stdin);
        fprintf(fptr, "Question %d: %s", existingQuestions + i + 1, question);
        
        int j;

        // Input options (A, B, C, D)
        for (j = 0; j < 4; j++)
        {
            printf("Enter option %c: ", 'A' + j);
            fgets(options[j], sizeof(options[j]), stdin);
            fprintf(fptr, "%c: %s", 'A' + j, options[j]);
        }

        // Input correct answer
        printf("Enter correct answer (A, B, C, D): ");
        scanf("%1s", answer);
        fprintf(fptr, "Answer: %s\n", answer);

        while ((getchar()) != '\n');
    }

    fclose(fptr);

    printf("Questions have been added to '%s' successfully!\n", fileName);
}


void viewQuestionPaper()
{
    FILE *fptr;
    char fileName[100];
    char line[1000]; // Adjust the buffer size as needed
    char coursename[50];
    
    printf("Enter the course name: ");
    scanf("%s", coursename);

    printf("Enter the name of the question paper file to view (without extension): ");
    scanf("%s", fileName);

    // Remove the newline character from the input
    fileName[strcspn(fileName, "\n")] = '\0';

    // Append ".txt" to the provided file name
    strcat(fileName, ".txt");

    // Create the complete file path
    char filePath[200];
    snprintf(filePath, sizeof(filePath), dirPath, coursename, fileName);

    // Open the file for reading
    fptr = fopen(filePath, "r");

    if (fptr == NULL)
    {
        perror("Error opening the file");
        return;
    }

    printf("Contents of '%s':\n", fileName);

    // Read and display the contents of the file line by line
    while (fgets(line, sizeof(line), fptr) != NULL)
    {
        printf("%s", line);
    }

    fclose(fptr);
}

void updateStudentMarks() {
	char filename[100];
	char coursename[50];
    
    printf("Enter the course name: ");
    scanf("%s", coursename);
	
    snprintf(filename, sizeof(filename), "courses/%s/students.csv", coursename);

    // Open the file for reading
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return;
    }

    // Open a temporary file for writing
    FILE *tempFile = fopen("temp.csv", "w");
    if (tempFile == NULL) {
        printf("Error opening temporary file for writing.\n");
        fclose(file);
        return;
    }

    char line[MAX_STRING_LENGTH * 7]; // Allow for all fields in a line
    
    long int regNum;
    float sub1, sub2, sub3, sub4, sub5;

    // Prompt for the registration number
    printf("Enter the registration number of the student: ");
    scanf("%ld", &regNum);

    // Prompt for the marks of all 5 subjects
    printf("Enter marks for Subject 1: ");
    scanf("%f", &sub1);

    printf("Enter marks for Subject 2: ");
    scanf("%f", &sub2);

    printf("Enter marks for Subject 3: ");
    scanf("%f", &sub3);

    printf("Enter marks for Subject 4: ");
    scanf("%f", &sub4);

    printf("Enter marks for Subject 5: ");
    scanf("%f", &sub5);

    // Read and process each line
    while (fgets(line, sizeof(line), file) != NULL) {
        Student student;
        int numFields = sscanf(line, "%ld,%[^,],%f,%f,%f,%f,%f,%[^,]", 
            &student.regNumber, student.name, &student.sub1_marks, &student.sub2_marks, 
            &student.sub3_marks, &student.sub4_marks, &student.sub5_marks, student.password);

        if (numFields != 8) {
            printf("Error parsing line: %s\n", line);
            continue; // Skip invalid lines
        }

        // Check if the registration number matches
        if (student.regNumber == regNum) {
            // Update the marks
            student.sub1_marks = sub1;
            student.sub2_marks = sub2;
            student.sub3_marks = sub3;
            student.sub4_marks = sub4;
            student.sub5_marks = sub5;
        }

        // Write the student data to the temporary file
        fprintf(tempFile, "%ld,%s,%.2f,%.2f,%.2f,%.2f,%.2f,%s\n", 
            student.regNumber, student.name, student.sub1_marks, student.sub2_marks, 
            student.sub3_marks, student.sub4_marks, student.sub5_marks, student.password);
    }

    // Close both files
    fclose(file);
    fclose(tempFile);

    // Replace the original file with the temporary file
    if (remove(filename) == 0 && rename("temp.csv", filename) == 0) {
        printf("Student marks updated successfully.\n");
    } else {
        printf("Error updating student marks.\n");
    }
}

void viewStudentDetails() {
    char filename[100];
	char coursename[50];
    
    printf("Enter the course name: ");
    fgets(coursename, sizeof(coursename), stdin);
	coursename[strcspn(coursename, "\n")] = '\0';
	
    snprintf(filename, sizeof(filename), "courses/%s/students.csv", coursename);

    // Open the file for reading
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return;
    }
    
    long int regNum;
    
    printf("Enter the student's Reg. No.: ");
    scanf("%ld", &regNum);
//    printf()

    char line[MAX_STRING_LENGTH * 7]; // Allow for all fields in a line

    // Read and process each line
    while (fgets(line, sizeof(line), file) != NULL) {
        Student student;
        int numFields = sscanf(line, "%ld,%[^,],%f,%f,%f,%f,%f,%[^,]", 
            &student.regNumber, student.name, &student.sub1_marks, &student.sub2_marks, 
            &student.sub3_marks, &student.sub4_marks, &student.sub5_marks, student.password);

        if (numFields != 8) {
            printf("Error parsing line: %s\n", line);
            continue; // Skip invalid lines
        }

        // Check if the registration number matches
        if (student.regNumber == regNum) {
            // Display student details
            printf("Registration Number: %ld\n", student.regNumber);
            printf("Name: %s\n", student.name);
            printf("Subject 1 Marks: %.2f\n", student.sub1_marks);
            printf("Subject 2 Marks: %.2f\n", student.sub2_marks);
            printf("Subject 3 Marks: %.2f\n", student.sub3_marks);
            printf("Subject 4 Marks: %.2f\n", student.sub4_marks);
            printf("Subject 5 Marks: %.2f\n", student.sub5_marks);
            fclose(file);
            return; 
        }
    }

    printf("Student with registration number %ld not found.\n", regNum);
    fclose(file);
}
